package com.example.appello ;
import androidx.appcompat.app.AppCompatActivity ;
import android.os.Bundle ;
import android.text.method.HideReturnsTransformationMethod ;
import android.text.method.PasswordTransformationMethod ;
import android.util.Patterns;
import android.view.View ;
import android.widget.Button ;
import android.widget.CheckBox ;
import android.widget.CompoundButton;
import android.widget.EditText ;
import android.widget.TextView ;
import android.widget.Toast ;

public class MainActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState) ;
        LOGIN() ;

    }

    public void LOGIN(){

        setContentView(R.layout.login) ;

        Button buttonLog = (Button) findViewById(R.id.buttonLog) ;
        Button buttonReg = (Button) findViewById(R.id.buttonReg) ;
        CheckBox mostra_pass = (CheckBox) findViewById(R.id.mostraPass) ;

        EditText username = (EditText) findViewById(R.id.username) ;
        EditText pass = (EditText) findViewById(R.id.pass) ;

        final Toast[] mToast = {null} ;

        mostra_pass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {

                    pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance()) ;
                }
                else {

                    pass.setTransformationMethod(PasswordTransformationMethod.getInstance()) ;
                }

            }
        }) ;

        buttonLog.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if(username.getText().toString().equals("admin") && pass.getText().toString().equals("admin")){

                    //Da richiamare con utente
                    SCELTA_INDIRIZZO() ;
                }

                else{

                    if (mToast[0] != null) mToast[0].cancel() ;
                    mToast[0] = Toast.makeText(MainActivity.this, "Credenziali errate!", Toast.LENGTH_SHORT) ;
                    mToast[0].show() ;
                }
            }
        }) ;

        buttonReg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                REGISTRAZIONE() ;
            }
        }) ;
    }

    public void REGISTRAZIONE() {

        setContentView(R.layout.registrazione) ;

        TextView buttonTorna, buttonReg ;
        EditText nome, cognome, email, pass1, pass2 ;

        CheckBox mostra_pass1 = (CheckBox) findViewById(R.id.mostraPass1) ;
        CheckBox mostra_pass2 = (CheckBox) findViewById(R.id.mostraPass2) ;

        buttonTorna = (TextView) findViewById(R.id.buttonTorna) ;
        buttonReg = (TextView) findViewById(R.id.buttonReg) ;

        nome = (EditText) findViewById(R.id.nome) ;
        cognome = (EditText) findViewById(R.id.cognome) ;
        email = (EditText) findViewById(R.id.email) ;
        pass1 = (EditText) findViewById(R.id.pass1) ;
        pass2 = (EditText) findViewById(R.id.pass2) ;

        Toast[] mToast = {null} ;

        mostra_pass1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {

                    pass1.setTransformationMethod(HideReturnsTransformationMethod.getInstance()) ;
                }
                else {

                    pass1.setTransformationMethod(PasswordTransformationMethod.getInstance()) ;
                }
            }
        }) ;

        mostra_pass2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b) {

                    pass2.setTransformationMethod(HideReturnsTransformationMethod.getInstance()) ;
                }
                else {

                    pass2.setTransformationMethod(PasswordTransformationMethod.getInstance()) ;
                }
            }
        }) ;


        buttonReg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                String Nome = nome.getText().toString().trim() ;
                String Cognome = cognome.getText().toString().trim() ;
                String Email = email.getText().toString().trim() ;
                String Pass1 = pass1.getText().toString().trim() ;
                String Pass2 = pass2.getText().toString().trim() ;

                if(Nome.isEmpty()){

                    nome.setError("Campo obbligatorio") ;
                    nome.requestFocus() ;
                    return ;
                }

                if(Cognome.isEmpty()){

                    cognome.setError("Campo obbligatorio") ;
                    cognome.requestFocus() ;
                    return ;
                }

                if(Email.isEmpty()){

                    email.setError("Campo obbligatorio") ;
                    email.requestFocus() ;
                    return ;
                }

                if(!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {

                    email.setError("Campo non valido") ;
                    email.requestFocus() ;
                    return ;
                }

                if(Pass1.isEmpty()){

                    pass1.setError("Campo obbligatorio") ;
                    pass1.requestFocus() ;
                    return ;
                }

                if(pass1.length() < 6){

                    pass1.setError("La password deve essere lunga almeno 6 caratteri") ;
                    pass1.requestFocus() ;
                }

                else if(Pass2.isEmpty()){

                    pass2.setError("Campo obbligatorio") ;
                    pass2.requestFocus() ;
                    return ;
                }

                else if(!Pass1.equals(Pass2)){

                    if (mToast[0] != null) mToast[0].cancel() ;
                    mToast[0] = Toast.makeText(MainActivity.this, "Le password non corrispondono!", Toast.LENGTH_SHORT) ;
                    mToast[0].show() ;
                }

                else {

                    if (mToast[0] != null) mToast[0].cancel() ;
                    mToast[0] = Toast.makeText(MainActivity.this, "Registrazione effettuata correttamente", Toast.LENGTH_SHORT) ;
                    mToast[0].show() ;
                    LOGIN() ;
                }
            }
        }) ;

        buttonTorna.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                LOGIN() ;
            }
        }) ;
    }

    public void SCELTA_INDIRIZZO(/*Uttente u*/) {

        setContentView(R.layout.indirizzo) ;
        TextView docente = (TextView) findViewById(R.id.Docente) ;    // Per: Salve 'nome docente'
        docente.setText("'cognome' 'nome'") ;                         //in futuro da sostituire con: docente.setText(u.cognome + " " + u.nome) ;

        Button DiVittorio = (Button) findViewById(R.id.button1) ;
        Button Lattanzio = (Button) findViewById(R.id.button2) ;
        Button ScienzeApplicate = (Button) findViewById(R.id.button3) ;

        DiVittorio.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                //Da richiamare con utente e ...
                SCELTA_ANNO("Di Vittorio") ;
            }
        });

        Lattanzio.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                //Da richiamare con utente e ...
                SCELTA_ANNO("Lattanizo") ;
            }
        });

        ScienzeApplicate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                //Da richiamare con utente e ...
                SCELTA_ANNO("Liceo scientifico scienze applicate") ;
            }
        }) ;
    }

    public void SCELTA_ANNO(/*Uttente u,*/ String scelta) {

        setContentView(R.layout.classi) ;

        Button a = (Button) findViewById(R.id.button1o) ;
        Button b = (Button) findViewById(R.id.button2o) ;
        Button c = (Button) findViewById(R.id.button3o) ;
        Button d = (Button) findViewById(R.id.button4o) ;
        Button e = (Button) findViewById(R.id.button5o) ;

        Button back = (Button) findViewById(R.id.back) ;

        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                SCELTA_INDIRIZZO() ;
            }
        }) ;

        TextView docente = (TextView) findViewById(R.id.Docente) ;    // Per: Docente: 'nome docente'
        docente.setText("'cognome' 'nome'") ;                         //in futuro da sostituire con: docente.setText(u.cognome + " " + u.nome) ;

        TextView s = (TextView) findViewById(R.id.scelta) ;
        if (scelta == "Liceo scientifico scienze applicate")
            s.setText("Liceo scientifico:") ;
        else
            s.setText(scelta + ":") ;

        a.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                switch (scelta) {

                    case "Di Vittorio" :

                        setContentView(R.layout.sezioni_1_div) ;
                        break ;

                    case "Lattanizo" :

                        setContentView(R.layout.sezioni_l1) ;
                        break ;

                    case "Liceo scientifico scienze applicate" :

                        setContentView(R.layout.sezioni_ls1) ;
                        break ;
                }
            }
        }) ;

        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                switch (scelta) {

                    case "Di Vittorio" :

                        setContentView(R.layout.sezioni_2_div) ;
                        break ;

                    case "Lattanizo" :

                        setContentView(R.layout.sezioni_l2) ;
                        break ;

                    case "Liceo scientifico scienze applicate" :

                        setContentView(R.layout.sezioni_ls2) ;
                        break ;
                }
            }
        }) ;

        c.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                switch (scelta) {

                    case "Di Vittorio" :

                        setContentView(R.layout.sezioni_3_div) ;
                        break ;

                    case "Lattanizo" :

                        setContentView(R.layout.sezioni_l3) ;
                        break ;

                    case "Liceo scientifico scienze applicate" :

                        setContentView(R.layout.sezioni_ls3) ;
                        break ;
                }
            }
        }) ;

        d.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                switch (scelta) {

                    case "Di Vittorio" :

                        setContentView(R.layout.sezioni_4_div) ;
                        break ;

                    case "Lattanizo" :

                        setContentView(R.layout.sezioni_l4) ;
                        break ;

                    case "Liceo scientifico scienze applicate" :

                        setContentView(R.layout.sezioni_ls4) ;
                        break ;
                }
            }
        }) ;

        e.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                switch (scelta) {

                    case "Di Vittorio" :

                        setContentView(R.layout.sezioni_5_div) ;
                        break ;

                    case "Lattanizo" :

                        setContentView(R.layout.sezioni_l5) ;
                        break ;

                    case "Liceo scientifico scienze applicate" :

                        setContentView(R.layout.sezioni_ls5) ;
                        break ;
                }
            }
        }) ;
    }
}