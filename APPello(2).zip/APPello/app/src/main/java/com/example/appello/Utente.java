package com.example.appello;

public class Utente {

    public String nome, cognome, email, pass ;

    public Utente(String nome, String cognome, String email){

        this.nome = nome ;
        this.cognome = cognome ;
        this.email = email ;
    }
}